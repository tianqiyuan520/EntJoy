using Godot;
using System.Diagnostics;
using System.Threading.Tasks;
using Vector3 = System.Numerics.Vector3;

public partial class TestGridSearch : Node
{
    [Export] public Label mytext;
    [Export] public int N = 100000;
    [Export] public int K = 100000;

    Vector3[] pos = null;
    Vector3[] queries = null;

    public override void _Ready()
    {
        _ = RunBenchmark();
    }

    // 保存 Vector3 数组到二进制文件
    private void SaveVector3Array(string path, Vector3[] array)
    {
        using var file = FileAccess.Open(path, FileAccess.ModeFlags.Write);
        foreach (var v in array)
        {
            file.StoreFloat(v.X);
            file.StoreFloat(v.Y);
            file.StoreFloat(v.Z);
        }
    }

    // 从二进制文件加载 Vector3 数组
    private Vector3[] LoadVector3Array(string path, int expectedLength)
    {
        using var file = FileAccess.Open(path, FileAccess.ModeFlags.Read);
        var list = new System.Collections.Generic.List<Vector3>();
        while (file.GetPosition() < file.GetLength())
        {
            float x = file.GetFloat();
            float y = file.GetFloat();
            float z = file.GetFloat();
            list.Add(new Vector3(x, y, z));
        }
        if (list.Count != expectedLength)
            GD.PrintErr($"Warning: loaded {list.Count} elements, expected {expectedLength}");
        return list.ToArray();
    }

    private async Task RunBenchmark()
    {
        await Task.Delay(1);

        string posPath = "user://pos.bin";
        string queriesPath = "user://queries.bin";

        GD.Print($"Data file path for pos: {ProjectSettings.GlobalizePath(posPath)}");
        GD.Print($"Data file path for queries: {ProjectSettings.GlobalizePath(queriesPath)}");

        // 尝试从文件加载
        if (FileAccess.FileExists(posPath) && FileAccess.FileExists(queriesPath))
        {
            GD.Print("Loading data from files...");
            pos = LoadVector3Array(posPath, N);
            queries = LoadVector3Array(queriesPath, K);
        }
        else
        {
            GD.Print("Generating new random data...");
            pos = new Vector3[N];
            GD.Seed(1235);
            for (int i = 0; i < N; i++)
            {
                pos[i] = new Vector3(
                    (float)GD.RandRange(-100.0f, 100.0f),
                    (float)GD.RandRange(-100.0f, 100.0f),
                    0
                );
            }

            queries = new Vector3[K];
            for (int i = 0; i < K; i++)
            {
                queries[i] = new Vector3(
                    (float)GD.RandRange(-100.0f, 100.0f),
                    (float)GD.RandRange(-100.0f, 100.0f),
                    0
                );
            }

            // 保存到文件
            SaveVector3Array(posPath, pos);
            SaveVector3Array(queriesPath, queries);
        }

        GD.Print("pos (first 10):");
        for (int i = 0; i < 10; i++)
            GD.Print(pos[i]);

        GD.Print("queries (first 10):");
        for (int i = 0; i < 10; i++)
            GD.Print(queries[i]);

        float meanCreation = 0.0f;
        float meanQuery = 0.0f;
        int timesTest = 100;
        int[] lastresults = null;

        Stopwatch sw = new Stopwatch();

        for (int i = 0; i < timesTest; i++)
        {
            sw.Restart();

            var gsb = new GridSearch2D_SIMD(-1f, 200);
            var handle = gsb.InitializeGrid(pos);
            handle.Complete();

            sw.Stop();
            float res1 = (float)sw.Elapsed.TotalMilliseconds;
            if (i != 0) meanCreation += res1;

            sw.Restart();
            int[] results = gsb.SearchClosestPoint(queries);
            lastresults = results;
            sw.Stop();
            float res2 = (float)sw.Elapsed.TotalMilliseconds;
            if (i != 0) meanQuery += res2;

            gsb.Dispose();
        }

        meanCreation /= (timesTest - 1);
        meanQuery /= (timesTest - 1);

        if (mytext != null)
        {
            mytext.Text =
                "Creation " + meanCreation.ToString("f3") + "ms\n" +
                "Search = " + meanQuery.ToString("f3") + " ms\n";
        }
        GD.Print("Creation " + meanCreation.ToString("f3") + "ms");
        GD.Print("Queries " + meanQuery.ToString("f3") + "ms");

        GD.Print("result: ");
        for (int i = 0; i < 10; i++)
            GD.Print(lastresults[i]);
    }
}